package riskgame.model.BasicClass.ObserverPattern;

import java.util.Observable;

/**
 * observable class for country
 **/
public class CountryObservable extends Observable {
}
