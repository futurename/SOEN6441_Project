package riskgame.model.BasicClass.Observe;

import java.util.Observable;

/**
 * observable class for country
 **/
public class CountryObservable extends Observable {
}
