package test;

/**
 * demo graph for test
 *
 * @author WW
 **/

public class GraphTester {

}
