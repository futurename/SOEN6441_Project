package test.riskgame.model.BasicClass.StrategyPattern; 

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 

/** 
* StrategyHuman Tester. 
* 
* @author  Karamveer
* @since <pre>Apr 2, 2019</pre> 
* @version 1.0 
*/ 
public class StrategyHumanTest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 

/** 
* 
* Method: doAttack(Player humanPlayer, Country attackingCountry, Country defendingCountry, int attackArmyNbr, int defendArmyNbr, boolean allout) 
* 
*/ 
@Test
public void testDoAttack() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: doReinforcement(Player humanPlayer, Country country, int army) 
* 
*/ 
@Test
public void testDoReinforcement() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: doFortification(Country from, Country to, int army) 
* 
*/ 
@Test
public void testDoFortification() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: toString() 
* 
*/ 
@Test
public void testToString() throws Exception { 
//TODO: Test goes here... 
} 


} 
