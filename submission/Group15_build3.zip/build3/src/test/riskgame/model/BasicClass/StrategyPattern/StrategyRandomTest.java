package test.riskgame.model.BasicClass.StrategyPattern; 

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 

/** 
* StrategyRandom Tester. 
* 
* @author Karamveer
* @since <pre>Apr 2, 2019</pre> 
* @version 1.0 
*/ 
public class StrategyRandomTest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 

/** 
* 
* Method: doReinforcement(Player player, PhaseViewObservable observable) 
* 
*/ 
@Test
public void testDoReinforcement() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: doAttack(Player player) 
* 
*/ 
@Test
public void testDoAttack() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: doFortification(Player player) 
* 
*/ 
@Test
public void testDoFortification() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: toString() 
* 
*/ 
@Test
public void testToString() throws Exception { 
//TODO: Test goes here... 
} 


/** 
* 
* Method: randomlyDeployArmy(Player player) 
* 
*/ 
@Test
public void testRandomlyDeployArmy() throws Exception { 
//TODO: Test goes here... 
/* 
try { 
   Method method = StrategyRandom.getClass().getMethod("randomlyDeployArmy", Player.class); 
   method.setAccessible(true); 
   method.invoke(<Object>, <Parameters>); 
} catch(NoSuchMethodException e) { 
} catch(IllegalAccessException e) { 
} catch(InvocationTargetException e) { 
} 
*/ 
} 


@Test
public void testRandomlyPickCountryFrom() throws Exception { 
//TODO: Test goes here... 
/* 
try { 
   Method method = StrategyRandom.getClass().getMethod("randomlyPickCountryFrom", ArrayList<Country>.class); 
   method.setAccessible(true); 
   method.invoke(<Object>, <Parameters>); 
} catch(NoSuchMethodException e) { 
} catch(IllegalAccessException e) { 
} catch(InvocationTargetException e) { 
} 
*/ 
} 

/** 
* 
* Method: randomlyExchangeCard(Player player, PhaseViewObservable observable) 
* 
*/ 
@Test
public void testRandomlyExchangeCard() throws Exception { 
//TODO: Test goes here... 
/* 
try { 
   Method method = StrategyRandom.getClass().getMethod("randomlyExchangeCard", Player.class, PhaseViewObservable.class); 
   method.setAccessible(true); 
   method.invoke(<Object>, <Parameters>); 
} catch(NoSuchMethodException e) { 
} catch(IllegalAccessException e) { 
} catch(InvocationTargetException e) { 
} 
*/ 
} 

/** 
* 
* Method: randomlyAttack(Player player) 
* 
*/ 
@Test
public void testRandomlyAttack() throws Exception { 
//TODO: Test goes here... 
/* 
try { 
   Method method = StrategyRandom.getClass().getMethod("randomlyAttack", Player.class); 
   method.setAccessible(true); 
   method.invoke(<Object>, <Parameters>); 
} catch(NoSuchMethodException e) { 
} catch(IllegalAccessException e) { 
} catch(InvocationTargetException e) { 
} 
*/ 
} 

/** 
* 
* Method: randomlyFortify(Player player) 
* 
*/ 
@Test
public void testRandomlyFortify() throws Exception { 
//TODO: Test goes here... 
/* 
try { 
   Method method = StrategyRandom.getClass().getMethod("randomlyFortify", Player.class); 
   method.setAccessible(true); 
   method.invoke(<Object>, <Parameters>); 
} catch(NoSuchMethodException e) { 
} catch(IllegalAccessException e) { 
} catch(InvocationTargetException e) { 
} 
*/ 
} 

} 
