package test.riskgame.model.BasicClass.StrategyPattern;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * @author Wei Wang
 * @version 1.0
 * @since 2019/04/09
 **/

@RunWith(Suite.class)
@Suite.SuiteClasses({

        StrategyHumanTest.class,
        StrategyHumanTest.class
})
public class StragegyPatternSuiteTest {
}
